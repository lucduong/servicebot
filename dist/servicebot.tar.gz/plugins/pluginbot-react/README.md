# pluginbot-react
Provides components and functions used to integrate Pluginbot with a React application, allows components to consume Pluginbot services


###Basic Usage

Using [Pluginbot](https://github.com/service-bot/pluginbot) you can create client-side plugins which can be bundled 
via webpack. These client plugins have all the same functionality as the server ones and will run on the browser. 

With this module you can connect your pluginbot plugin's to React via a Pluginbot provider wrapper which doubles as a
Redux provider


```javascript


```

####