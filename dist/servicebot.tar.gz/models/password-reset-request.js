
let ResetRequest = require("./base/entity")("password_reset_request");

module.exports = ResetRequest;