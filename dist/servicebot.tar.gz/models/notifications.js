
let Notification = require("./base/entity")("notifications");


//Notification.createFromTemplate()

module.exports = Notification;