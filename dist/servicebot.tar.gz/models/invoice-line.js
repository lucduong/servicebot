
let InvoiceLines = require("./base/entity")("user_invoice_lines");


module.exports = InvoiceLines;