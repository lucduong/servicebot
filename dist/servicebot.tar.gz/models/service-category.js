
var ServiceCategory = require("./base/entity")("service_categories");


module.exports = ServiceCategory;
